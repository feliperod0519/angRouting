import {NgModule} from '@angular/core';
import {Routes, RouterModule, PreloadAllModules, UrlSerializer} from '@angular/router';


const routes: Routes = [

];

@NgModule({
  imports: [

  ],
  exports: [RouterModule],
  providers: [

  ]
})
export class AppRoutingModule {


}
