

export interface User {
  id:string;
  email:string;
  pictureUrl:string;
}
